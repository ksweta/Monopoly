$(document).ready( function(){
	alert("hello from custom");
});
